import { initializeApp } from 'firebase/app'
import {
  getAuth,
  GoogleAuthProvider,
  setPersistence,
  browserLocalPersistence
} from 'firebase/auth'
import { initializeFirestore,getFirestore } from 'firebase/firestore'

const firebaseConfig = {
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY,
  authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN,
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID,
  storageBucket: import.meta.env.VITE_FIREBASE_STORAGE_BUCKET,
  messagingSenderId: import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID,
  appId: import.meta.env.VITE_FIREBASE_APP_ID
}

// const app = initializeApp(firebaseConfig)
// const auth = getAuth(app)
// const db = initializeFirestore(app, {
//   experimentalForceLongPolling: true
// })
// const googleProvider = new GoogleAuthProvider()

// setPersistence(auth, browserLocalPersistence)

const app = initializeApp(firebaseConfig)

 const auth = getAuth(app)
 const db = getFirestore(app)
 const googleProvider = new GoogleAuthProvider()

 
export { app, auth, db, googleProvider }
